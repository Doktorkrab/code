#include <cassert>

long long GetN() {
  return 1;
}
long long GetElement(long long i) {
    assert(i == 0);
    return (long long)227;
}
